# Clear workspace
rm(list = ls())
setwd("C:/Users/Rudi/Dropbox/RCoding/ProjektR")


# install.packages("ggplot2", dependencies = T)
# install.packages("dplyr", dependencies = T)
# install.packages("tidyr", dependencies = T)

source("util.R")
source("multiplot.R")
source("loadingData.R")
source("Aufgabe1.R")
source("Aufgabe2.R")
source("Aufgabe3.R")
source("Aufgabe4.R")
source("Aufgabe5.R")
source("Aufgabe6.R")
source("Aufgabe7.R")
source("Aufgabe8.R")
source("Aufgabe9.R")