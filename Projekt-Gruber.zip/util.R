# Utility script where auxiliary functions are implemented

library(tidyr)


# function for summary statistics
# necessary for task 2 and 3
summary.stats <- function(vec, ...) {
  # does the function contain a parameter
  if (missing(vec)) {
    stop("Der Funktion muss ein Vektor als Parameter übergeben werden")
  }
  
  # parsing Parameter to a vector object for sapply
  vec <- as.vector(vec)
  
  # vector of length 1 is a scalar
  if (length(vec) < 2L) {
    stop("Der Funktion muss ein Vektor als Parameter übergeben werden")
  }
  
  # 2 seperate if'S for checking 1 parameter is a
  # clumsy coding style but it does the job
  
  stats <- vector(length = 5) # Initialising return vector
  stats <- as.vector(stats, mode = "any") # any for mixed content
  
  # warning about missings
  # if numeric variables contain missings, na.rm must be specified
  # additionally for calculations
  
  if (any(is.na(vec))) {
    warning("Der Übergebene Vektor enthält NA Werte")
  }
  
  # Counting non NA values
  stats[1] <- sum(!is.na(vec))
  
  print("ich bin vor is.numeric")
  # debug because
  # apply is not executing the if branch
  # worked fine after switching to sapply
  
  if (is.numeric(vec)) {
    print("ich bin nach is.numeric")
    stats[2] <- NA
    stats[3] <- round(median(vec, na.rm = T), 2)
    stats[4] <- round(min(vec, na.rm = T), 2)
    stats[5] <- round(max(vec, na.rm = T), 2)
  }
  else {
    print("Ich bin im else")
    stats[2] <- length(unique(vec))
    stats[3] <- NA
    stats[4] <- NA
    stats[5] <- NA
  }
  print("ich gebe stats zurück")
  return(stats)
} # summary.stats




# Implementation of the converting function for task 8
string2numeric <-
  function(vec = vector(),
           method = c("mean", "min", "max", "uniform")) {
    print("start checks")
    
    ### Checking Inputs ###############################################
    if (missing(vec) || missing(method)) {
      stop("Der Funktion müssen ein Vektor und eine Methodenspezifikation übergeben werden")
    }
    
    print("missing")
    
    # Datatype == vector?
    # Parsing
    if (is.vector(vec) == F) {
      warning(
        "Der Datentyp des Parameters entspricht nicht einem Vektor /n
        Es wird versucht den Input zu parsen"
      )
      vec <- as.vector(vec)
    }
    
    print("is.vector")
    # Vector of letters?
    if (F %in% sapply(vec, is.character)) {
      warning("Der übergebene Vektor enthält Einträge, die keine Buchstaben sind!")
      vec <- as.character(vec)
    }
    
    # Vector of length 1 is a scalar
    if (length(vec) == 1L) {
      stop("Der Funktion muss ein Vektor als Parameter übergeben werden")
    }
    
    print("vector length")
    
    # Missings?
    if (any(is.na(vec))) {
      warning("Der Vektor enthält NA Werte")
    }
    
    print("missings")
    
    # Allowable methods specified in Parameter?
    methods <- c("mean", "min", "max", "uniform")
    if (!tolower(method) %in% methods) {
      stop(
        "Sie haben eine Berechnungsmethode für den Repräsentanten spezifiziert, die in dieser
        Funktion nicht implementiert ist!"
      )
    }
    
    print("methods")
    
    ### Program Logic ###########################################
    
    
    # Initializing Vector for the parsed values
    returnvalues <- vector(mode = "numeric", length = length(vec))
    
    # Notes:
    # Es muss identifiziert werden, ob ein Eintrag atomar oder Vector ist
    # Atomare Werte in numeric parsen
    # Vector Splitten in Min und Max Value
    # Selektion eines Repräsentanten gemäß der Auswahl
    
    # Splitting intervals
    vec <- as.data.frame(vec)
    names(vec) <- c("Numbers")
    vec <- separate(
      vec,
      Numbers,
      into = c("Min", "Max"),
      sep = "-",
      convert = T,
      remove = F
    )
    
    # Single value: Min = Entry, Max = NA
    # Intervall: Min = Entry, Max = Entry
    
    method <- match.arg(method)
    
    for (i in 1:nrow(vec)) {
      # Entry for Intervalls
      if (is.na(vec[i, ]$Max) == F) {
        # Representative according to method
        if (method == "mean") {
          returnvalues[i] <- (vec[i, ]$Min + vec[i, ]$Max) / 2
        }
        
        if (method == "min") {
          returnvalues[i] <- vec[i, ]$Min
        }
        
        if (method == "max") {
          returnvalues[i] <- vec[i, ]$Max
        }
        
        if (method == "uniform") {
          returnvalues[i] <- runif(1, min = vec[i, ]$Min, max = vec[i, ]$Max)
        }
        
        print(i)
        
      } else{
        # assigning non intervall
        returnvalues[i] <- vec[i, ]$Min
        print(i)
      }
    }# for
    return(as.numeric(returnvalues))
    } # string2numeric


# Function for key figures of task 8 
simple.summary <-
  function(vec = vector(),
           method = c("mean", "median", "sd", "iqr"),
           ...) {
    ### Checking Inputs ###############################################
    if (missing(vec) || missing(method)) {
      stop("Der Funktion müssen ein Vektor und eine Methodenspezifikation übergeben werden")
    }
    
    # Datatype == vector?
    # Parsing
    if (is.vector(vec) == F) {
      warning(
        "Der Datentyp des Parameters entspricht nicht einem Vektor /n
        Es wird versucht den Input zu parsen"
      )
      vec <- as.vector(vec)
    }
    
    
    # Vector of length 1 is a scalar
    if (length(vec) == 1L) {
      stop("Der Funktion muss ein Vektor als Parameter übergeben werden")
    }
    
    
    # Missings?
    if (any(is.na(vec))) {
      warning("Der Vektor enthält NA Werte")
    }
    
    # Allowable methods specified in Parameter?
    methods <- c("mean", "median", "sd", "iqr")
    if (!tolower(method) %in% methods) {
      stop(
        "Sie haben eine Berechnungsmethode für den Repräsentanten spezifiziert, die in dieser
        Funktion nicht implementiert ist!"
      )
    }
    
    
    ### Program Logic ###########################################
    
    method <- match.arg(method)
    
    if (method == "mean") {
      return(mean(vec, na.rm = T))
    }
    
    if (method == "median") {
      return(median(vec, na.rm = T))
    }
    
    if (method == "sd") {
      return(sd(vec, na.rm = T))
    }
    
    if (method == "iqr") {
      return(IQR(vec, na.rm = T))
    }
    
    } # simple.summary